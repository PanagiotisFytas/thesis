void *divider(void* arg) {
  int x = 0;
  return 42/x;
}
