nidhuggc -I v4.7 -std=gnu99 -- --sc --extfun-no-race=fprintf --extfun-no-race=memcpy --print-progress-estimate --disable-mutex-init-requirement --unroll=5 litmus.c
