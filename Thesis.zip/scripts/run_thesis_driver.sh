# ./thesis_driver.sh L 0 > LB_0.out 
# ./thesis_driver.sh L 1 > LB_1.out 
# ./thesis_driver.sh L 2 > LB_2.out 
# ./thesis_driver.sh L 3 > LB_3.out 
# ./thesis_driver.sh L 4 > LB_4.out 
./thesis_driver.sh PB 0 > PB_0.out
./thesis_driver.sh S 0 > S_0.out


#python3 table_maker.py VAN_4.out SB_4.out > bound_4.tex

